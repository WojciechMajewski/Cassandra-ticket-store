from pick import pick
from time import sleep

from src.Cassandra_main import *
from src.QueryEngine import QueryEngine

class MainMenu:
    def __init__(self, client: CassandraConnector):
        self.client = client
        self.query_engine = QueryEngine()
    
    def main(self):
        while(True):
            title = 'Please choose what you want to do on this beautiful day'
            options = ['List concerts', 'Buy a ticket', 'stress test 1', 'stress test 2', 'stress test 3', 'quit']
            option, index = pick(options, title, indicator='=>', default_index=0)
            if index == 5:
                break
            if index == 4:
                print('here i will stress test 3')
            if index == 3:
                print('here i will stress test 2')
            if index == 2:
                print('here i will stress test 1')
            if index == 1:
                print('here you can buy a ticket')
            if index == 0:
                self.list_all_concerts()
                sleep(10)
                
    def list_all_concerts(self):
        print("\n\n\n\nLISTING ALL SCENES")
        query = self.query_engine.SELECT_ALL('scene')
        query_result = self.client.execute_query(query)
        for line in query_result:
            scene_id, name, tickets = line
            #scene_name = self.get_scene_name(scene_id)
            print(f'{scene_id}, \t {name}, \t {tickets} \n')
        print("\n\n\n\nLISTING ALL CONCERTS")
        query = self.query_engine.SELECT_ALL('concert')
        query_result = self.client.execute_query(query)
        for line in query_result:
            concert_id, artist, available_tickets, concert_date, scene_id = line
            scene_name = self.get_scene_name(scene_id)
            print(f'Concert of {artist} at {scene_name}, where there are {len(available_tickets)} tickets available on {concert_date}\n')
        return query_result
    
    def get_scene_name(self, scene_id):
        query = self.query_engine.SELECT_WHERE('scene', 'scene_id', 'UUID', scene_id)
        scene_name = self.client.execute_query(query)[0][1]
        return scene_name

